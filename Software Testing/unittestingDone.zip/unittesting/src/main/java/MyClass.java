public class MyClass {
    public float div(float a, float b) {
        return a / b;
    }
}
