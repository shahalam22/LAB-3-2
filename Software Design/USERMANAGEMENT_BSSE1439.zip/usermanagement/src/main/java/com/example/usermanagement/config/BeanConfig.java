package com.example.usermanagement.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class BeanConfig {
    // bean configurations
}